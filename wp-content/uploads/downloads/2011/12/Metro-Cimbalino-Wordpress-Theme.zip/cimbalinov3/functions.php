<?php
/**
 * Metro Cimbalino functions and definitions
 *
 * @package WordPress
 * @subpackage MetroCimbalino
 * @since Metro Cimbalino 3.0
 */
add_action('after_setup_theme', 'cimbalino_setup');

if (!function_exists('cimbalino_setup')):

function cimbalino_setup()
{
	define('HEADER_IMAGE','%s/../cimbalinov3/images/cimbalino-header.png');
	
	register_default_headers(array(
		'cimbalino' => array(
			'url' => '%s/../cimbalinov3/images/cimbalino-header.png',
			'thumbnail_url' => '%s/../cimbalinov3/images/cimbalino-header-thumbnail.png',
			'description' => __('Cimbalino', 'cimbalino')
		)
	));
}
endif;
?>