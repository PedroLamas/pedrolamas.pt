﻿using System;
using System.IO;
using Microsoft.Phone.Controls;

namespace GetFileFromXap
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            var xapResolver = new System.Xml.XmlXapResolver();

            using (var currenciesStream = (Stream)xapResolver.GetEntity(new Uri("test.txt", UriKind.Relative), null, typeof(Stream)))
            {
                using (var streamReader = new StreamReader(currenciesStream))
                {
                    TestFileContentTextBox.Text = streamReader.ReadToEnd();
                }
            }
        }
    }
}